Run: streamlit run app.py

